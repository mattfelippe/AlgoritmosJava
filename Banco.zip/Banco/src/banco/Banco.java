package banco;

import java.util.ArrayList;
import java.util.List;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Collections;
import javax.swing.JOptionPane;

public class Banco {

    public static void main(String[] args) {
        final String nomeArquivo = "c:\\contas.obj";
        List <Conta> contas = new ArrayList<Conta>();
        
        leContas(nomeArquivo, contas);
        processaContas(contas); 
        gravaContas(nomeArquivo, contas);
    }

    public static void processaContas(List contas) {
        final int FIM = 5;
        int opcao;
        
        do {
            opcao = menu();
            switch (opcao) {
                case 1: incluirConta(contas);
                    break;
                case 2: alterarConta(contas);
                    break;
                case 3: excluirConta(contas);
                    break;
                case 4: relatorios(contas);
                    break;
            }
        } while (opcao != FIM);
    }
    
    public static int verificaConta(List<Conta> contas, int conta) {
        int pos = -1;
        
        for (int i = 0; i < contas.size(); i++) {
            if (contas.get(i).getConta() == conta) {
                pos = i;
                break;
            }
        }
        return pos;
    }
    
    public static double entraSaldo(String msg) {
        double saldo;
        
        do {
            saldo = Double.parseDouble(JOptionPane.showInputDialog(msg));
            if (saldo <= 0) {
                JOptionPane.showMessageDialog(null, "Erro: saldo inválido");
            }
        } while (saldo <= 0);
        return saldo;
    }
    
    public static void alterarConta(List<Conta> contas) {
        int numConta, pos;
        
        numConta = Integer.parseInt(JOptionPane.showInputDialog("Entre com o número da conta: "));
        pos = verificaConta(contas, numConta);
        if (pos == -1) {
            JOptionPane.showMessageDialog(null, "Erro: conta inválida");
            return;
        }
        contas.get(pos).setNome(JOptionPane.showInputDialog("Entre com o nome do cliente: "));
        contas.get(pos).setSaldoCC(Double.parseDouble(JOptionPane.showInputDialog("Entre com o novo saldo: ")));
        contas.get(pos).setSaldoPoupanca(Double.parseDouble(JOptionPane.showInputDialog("Entre com o novo saldo poupança: ")));
    }
    
    public static void incluirConta(List contas) {
        int numConta;
        
        numConta = Integer.parseInt(JOptionPane.showInputDialog("Entre com o número da conta: "));
        if (verificaConta(contas, numConta) != -1) {
            JOptionPane.showMessageDialog(null, "Erro: conta inválida");
            return;
        }
        Conta conta = new Conta();
        conta.setConta(numConta);
        conta.setNome(JOptionPane.showInputDialog("Entre com o nome do cliente: "));
        conta.setSaldoCC(entraSaldo("Entre com o saldo da CC: "));
        conta.setSaldoPoupanca(entraSaldo("Entre com o saldo da Poupança: "));
        contas.add(conta);
    }
    
    public static void excluirConta(List<Conta> contas) {
        int numConta, pos;
        
        numConta = Integer.parseInt(JOptionPane.showInputDialog("Entre com o número da conta: "));
        pos = verificaConta(contas, numConta);
        if (pos == -1) {
            JOptionPane.showMessageDialog(null, "Erro: conta inválida");
            return;
        }
        if (!contas.get(pos).saldoZerado() && (!contas.get(pos).saldoPoupancaZerado())) {
            JOptionPane.showMessageDialog(null, "Erro: conta com saldo positivo");
            return;
        }
        int opcao = Integer.parseInt(JOptionPane.showInputDialog(contas.get(pos) + "\n " +
                "Deseja excluir a conta? \n 1 - Sim\n2 - Não"));
        if (opcao == 1) {
            contas.remove(pos);
        }
    }
    
    public static int menu () {
        String opcao;
        int op;
        
        do {
            opcao = JOptionPane.showInputDialog("Selecione uma opção \n "
                + "1 - Incluir \n 2 - Alterar \n 3 - Excluir \n 4 - Relatórios "
                + "\n 5 - Sair");
            op = Integer.parseInt(opcao);
            if ((op < 1) || (op > 5)) {
                JOptionPane.showMessageDialog(null, "Erro: opcao inválida");
            }
        } while ((op < 1) || (op > 5));    
        return op;
    }

    public static int menuRelatorios () {
        String opcao;
        int op;
        
        do {
            opcao = JOptionPane.showInputDialog("Selecione uma opção \n "
                + "1 - Listar todas contas \n 2 - Listar contas negativas "
                + "\n 3 - Listar contas acima do valor \n 4 - Listar as três maiores contas"
                + "\n 5 - Sair");
            op = Integer.parseInt(opcao);
            if ((op < 1) || (op > 5)) {
                JOptionPane.showMessageDialog(null, "Erro: opcao inválida");
            }
        } while ((op < 1) || (op > 5));    
        return op;
    }
    
    public static void relatorios(List contas) {
        final int FIM = 5;
        int opcao;
        
        do {
            opcao = menuRelatorios();
            switch (opcao) {
                case 1: 
                    listarContas(contas);
                    break;
                case 2:
                    listarContasNegativas(contas);
                    break;
                case 3:
                    listarContasAcimaValor(contas);
                    break;
                case 4:
                    listarMaioresSaldos(contas);
                    break;
            }
        } while (opcao != FIM);
    }
    
    public static void leContas(String nome, List contas) {
        ObjectInputStream entrada = null;
    
        // Abre o arquivo
        try {
            entrada = new ObjectInputStream(new FileInputStream(nome));
        }
        catch (IOException erro) {
            System.out.println("Não foi possível abrir o arquivo");
            return;
        }
        // Le o arquivo
        boolean fim = false;
        do {
            try {
                contas.add(entrada.readObject());
            }
            catch (EOFException erro) {
                fim = true;
            }
            catch (ClassNotFoundException erro) {
                System.out.println("Erro: criacao do objeto");
            }
            catch (IOException erro) {
                System.out.printf("Erro: leitura do aqrquivo");
            }
        } while (fim == false);
        // Fechar o arquivo
        try {
            entrada.close();
        }
        catch (IOException erro) {
            System.err.println("Erro: fechando arquivo" );
            System.exit(1);
        }
    }
    
    public static void gravaContas(String nome, List contas) {
        ObjectOutputStream saida = null;
        
        try {
            saida = new ObjectOutputStream(new FileOutputStream(nome));
        }
        catch (IOException erro) {
            System.out.println("Erro: abertura do arquivo");
            System.exit(1);
        }
        try {
            for (int i = 0; i < contas.size(); i++) {
                saida.writeObject(contas.get(i));
            }
        }
        catch (IOException erro) {
            System.out.println("Erro: gravacao no arquivo");
        }
        try {
            saida.close();
        }
        catch (IOException erro) {
            System.err.println("Erro: fechando o arquivo");
            System.exit(1);
        }
    }
    
    public static void criarcontas (List contas){
      
        Conta conta1 = new Conta();
        conta1.setConta(1);
        conta1.setNome("lp");
        conta1.setSaldoPoupanca(1000);
        conta1.setSaldoCC(2000);
        contas.add(conta1);
        
        Conta conta2 = new Conta();
        conta2.setConta(2);
        conta2.setNome("fm");
        conta2.setSaldoPoupanca(3000);
        conta2.setSaldoCC(3000);
        contas.add(conta2);
        
        Conta conta3 = new Conta();
        conta3.setConta(3);
        conta3.setNome("ml");
        conta3.setSaldoPoupanca(3000);
        conta3.setSaldoCC(4000);
        contas.add(conta3);
    }
    
    public static void listarContas(List contas){
        
        if (contas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Não há contas a serem listadas");
            return;
        }
        System.out.println("---------------------");
        for (int i = 0; i < contas.size(); i++) {
            System.out.println(contas.get(i));
        }
        System.out.println("---------------------");
    }

    public static void listarContasNegativas(List<Conta> contas){
        boolean achou = false;
        
        if (contas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Não há contas a serem listadas");
            return;
        }
        System.out.println("---------------------");
        for (int i = 0; i < contas.size(); i++) {
            if (contas.get(i).getSaldoCC() < 0) {
                System.out.println(contas.get(i));
                achou = true;
            }
        }
        if (!achou) {
            System.out.println("Não existem contas negativadas");
        }
        System.out.println("---------------------");
    }

    public static void listarContasAcimaValor(List<Conta> contas) {
        boolean achou = false;
        
        if (contas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Não há contas a serem listadas");
            return;
        }
        double valor = Double.parseDouble(JOptionPane.showInputDialog("Entre com o valor: "));
        System.out.println("---------------------");
        for (int i = 0; i < contas.size(); i++) {
            if (contas.get(i).getSaldoCC() > valor) {
                System.out.println(contas.get(i));
                achou = true;
            }    
        }
        if (!achou) {
            System.out.println("Não existe saldo acima deste valor");
        }    
        System.out.println("---------------------");
    }   
    
    public static void listarMaioresSaldos(List<Conta> contas) {

        if (contas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Não há contas a serem listadas");
            return;
        }
        int tam;
        Collections.sort(contas);
        if (contas.size() > 3) {
            tam = 3;
        }
        else {
            tam = contas.size();
        }
        System.out.println("---------------------");
        for (int i = 0; i < tam; i++) {
            System.out.println(contas.get(i));
        }
        System.out.println("---------------------");
    }    
}