package matriz1;

import java.util.Scanner;

public class Matriz1 {
    public static void main(String[] args) {
        final int LINHAS = 5, COLUNAS = 4;
        int[][] matriz = new int[LINHAS][COLUNAS];
        Scanner entrada = new Scanner(System.in);
        int elemento;
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("Entre com um número: ");
                elemento = entrada.nextInt();
                matriz[i][j] = elemento;
            }
        }
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println("");
        }
    }
}
