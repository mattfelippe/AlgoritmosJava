package vetor2;

public class Vetor2 {
    public static void main(String[] args) {
        int[] vet = {1, 2, 3, 4, 5};
        
        for (int i = 0; i < vet.length; i++) {
            System.out.print(vet[i] + " ");
        }
    }
}
