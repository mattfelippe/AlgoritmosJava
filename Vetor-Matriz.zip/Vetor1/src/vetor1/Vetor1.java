package vetor1;

/* Faça um pgm que leia cinco notas, calcule a média e 
   mostre as notas maiores ou iguais a média */

import java.util.Scanner;

public class Vetor1 {
    public static void main(String[] args) {
        final int TAM = 5;
        int[] notas = new int[TAM];
        int nota, soma = 0;
        double media;
        Scanner entrada = new Scanner(System.in);
        
        for (int i = 0; i < notas.length; i++) {
            System.out.print("Entre com a nota: ");
            nota = entrada.nextInt();
            notas[i] = nota;
            soma = soma + nota;
        }
        media = (double) soma / TAM;
        System.out.println("Média = " + media);
        for (int i = 0; i < notas.length; i++) {
            if (notas[i] >= media) {
                System.out.println(notas[i]);
            }
        }
    }
}
