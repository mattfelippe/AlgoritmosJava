package heranca.banco;

public abstract class ContaBancaria {
    private int agencia;
    private int conta;
    private double saldo;
    private Pessoa titular;
    
    public void depositar(double valor) {
        
    } 
    
    public void sacar(double valor) {
        
    } 

    public double verSaldo() {
        double saldo = 0;
        
        return saldo;
    }
}
