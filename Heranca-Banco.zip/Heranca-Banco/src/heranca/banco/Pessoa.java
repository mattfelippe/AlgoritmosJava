package heranca.banco;

public class Pessoa {
    
}
