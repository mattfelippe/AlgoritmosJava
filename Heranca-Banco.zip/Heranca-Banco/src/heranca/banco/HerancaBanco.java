package heranca.banco;

public class HerancaBanco {
    public static void main(String[] args) {
        ContaSalario contaS = new ContaSalario(); 
        ContaPoupanca contaP = new ContaPoupanca(); 
        
        contaS.calcularTatifa();
    }
}
