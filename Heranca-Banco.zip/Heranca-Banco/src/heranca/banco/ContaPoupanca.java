package heranca.banco;

public class ContaPoupanca extends ContaBancaria {
    private double taxa;
    
    public double calcularRendimento() {
        double valor = 0;
        
        return valor;
    }    
}
