package heranca.banco;

public class ContaSalario extends ContaBancaria {
    private double taxa;
    
    public double calcularTatifa() {
        double valor = 0;
        
        return valor;
    }
}
