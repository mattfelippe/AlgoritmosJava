package repeticao1;

import java.util.Scanner;

public class Repeticao1 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int limite, cont = 0;
        
        System.out.print("Entre com o número de repetições: ");
        limite = entrada.nextInt();
        for (int i = 1; i <= limite; i += 5) {
            System.out.println("Valor de i = " + i);
            cont++;
        }
        System.out.println("Número de repetições = " + cont);
    }
}
