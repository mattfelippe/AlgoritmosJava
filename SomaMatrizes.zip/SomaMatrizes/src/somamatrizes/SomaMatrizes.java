package somamatrizes;

public class SomaMatrizes {
    public static void main(String[] args) {
        final int TAM = 2;
        int[][] a = {{1,2}, {3,4}};
        int[][] b = {{5,6}, {7,8}};
        int[][] c = new int[TAM][TAM];
        
        c = somaMatrizes(a, b);
        mostraMatriz(c);
    }
    
    public static int[][] somaMatrizes(int[][] a, int[][] b) {
        int[][] c = new int[2][2];
        
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                c[i][j] = a[i][j] + b[i][j];
            }
        }
        return c;
    }
    
    public static void mostraMatriz(int[][] matriz) {
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.printf("%2d ", matriz[i][j]);
            }
            System.out.println("");
        }
    }
}
