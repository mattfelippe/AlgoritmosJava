package lista2.ex8;

import java.util.Scanner;

public class Lista2Ex8 {
    public static void main(String[] args) {
        int ip;
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Entre com o endereço IP: ");
        ip = entrada.nextInt();
        if ((ip >= 0) && (ip <= 127)) {
            System.out.println("IP classe A");
        }
        else {
            if ((ip >= 128) && (ip <= 191)) {
                System.out.println("IP classe B");
            }
            else {
                if ((ip >= 192) && (ip <= 223)) {
                    System.out.println("IP classe C");
                }
                else {
                    if ((ip >= 224) && (ip <= 239)) {
                        System.out.println("IP classe D");
                    }
                    else {
                        if ((ip >= 240) && (ip <= 255)) {
                            System.out.println("IP classe E");
                        }
                        else {
                            System.out.println("IP inválido");
                        }
                    }
                }
            }
        }
    }
}
