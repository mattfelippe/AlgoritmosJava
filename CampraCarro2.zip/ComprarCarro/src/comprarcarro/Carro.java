package comprarcarro;

public class Carro {
    private String modelo;
    private double custoCompra;
    private double custoImposto;
    private double consumoCombustivel;
    private double custoSeguro;
    
    Carro() {
       
    }
    
    Carro(String modelo, double custoCompra, double custoImposto,
            double consumoCombustivel, double custoSeguro) {
        this.modelo = modelo;
        this.custoCompra = custoCompra;
        this.custoImposto = custoImposto;
        this.consumoCombustivel = consumoCombustivel;
        this.custoSeguro = custoSeguro;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getCustoCompra() {
        return custoCompra;
    }

    public void setCustoCompra(double custoCompra) {
        this.custoCompra = custoCompra;
    }

    public double getCustoImposto() {
        return custoImposto;
    }

    public void setCustoImposto(double custoImposto) {
        this.custoImposto = custoImposto;
    }

    public double getConsumoCombustivel() {
        return consumoCombustivel;
    }

    public void setConsumoCombustivel(double consumoCombustivel) {
        this.consumoCombustivel = consumoCombustivel;
    }

    public double getCustoSeguro() {
        return custoSeguro;
    }

    public void setCustoSeguro(double custoSeguro) {
        this.custoSeguro = custoSeguro;
    }
    
    @Override
    public String toString() {
        String msg;
        
        msg = modelo + " " + custoCompra + " " + custoImposto + " " + consumoCombustivel 
                + " " + custoSeguro;
        return msg;
    }
}
