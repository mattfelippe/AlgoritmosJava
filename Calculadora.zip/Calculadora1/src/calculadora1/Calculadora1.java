package calculadora1;

import java.util.Scanner;

public class Calculadora1 {
    public static void main(String[] args) {
        int operacao;
        double op1, op2, result = 0;
        Scanner entrada = new Scanner(System.in);

        System.out.println("1 - Soma");
        System.out.println("2 - Subtração");
        System.out.println("3 - Multiplicação");
        System.out.println("4 - Divisão");
        System.out.print("Escolha a operação: ");
        operacao = entrada.nextInt();
        if ((operacao >= 1) && (operacao <= 4)) {
            System.out.print("Entre com o operando: ");
            op1 = entrada.nextDouble();
            System.out.print("Entre com o operando: ");
            op2 = entrada.nextDouble();
            switch (operacao) {
                case 1:
                    result = op1 + op2;
                    System.out.println("Resultado = " + result);
                    break;
                case 2:
                    result = op1 - op2;
                    System.out.println("Resultado = " + result);
                    break;
                case 3: 
                    result = op1 * op2;
                    System.out.println("Resultado = " + result);
                    break;
                case 4:
                    if (op2 != 0) {
                        result = op1 / op2;
                        System.out.println("Resultado = " + result);
                    }
                    else {
                        System.out.println("Erro: divisão por zero");
                    }
                    break;
            }
        }
        else {
            System.out.println("Operacao inválida");
        }
    }
}