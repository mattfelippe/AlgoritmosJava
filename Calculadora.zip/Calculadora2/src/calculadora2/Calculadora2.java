package calculadora2;

import java.util.Scanner;

public class Calculadora2 {
    public static void main(String[] args) {
        int operacao;
        double result;
        
        operacao = Menu();
        result = Calcula(operacao);
    }
    
    public static double LeOperando(String msg) {
        double op;
        Scanner entrada = new Scanner(System.in);
        
        System.out.print(msg);
        op = entrada.nextDouble();
        return op;
    }
    
    public static double Calcula(int operacao) {
        double op1, op2, result = 0;

        if ((operacao >= 1) && (operacao <= 4)) {
            op1 = LeOperando("Entre com o operando 1: ");
            op2 = LeOperando("Entre com o operando 2: ");
            switch (operacao) {
                case 1:
                    result = op1 + op2;
                    System.out.println("Resultado = " + result);
                    break;
                case 2:
                    result = op1 - op2;
                    System.out.println("Resultado = " + result);
                    break;
                case 3: 
                    result = op1 * op2;
                    System.out.println("Resultado = " + result);
                    break;
                case 4:
                    if (op2 != 0) {
                        result = op1 / op2;
                        System.out.println("Resultado = " + result);
                    }
                    else {
                        System.out.println("Erro: divisão por zero");
                    }
                    break;
            }
        }
        else {
            System.out.println("Operacao inválida");
        }        
        return result;
    }
    
    public static int Menu() {
        int operacao;
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("1 - Soma");
        System.out.println("2 - Subtração");
        System.out.println("3 - Multiplicação");
        System.out.println("4 - Divisão");
        System.out.print("Escolha a operação: ");
        operacao = entrada.nextInt();
        return operacao;
    }
}
