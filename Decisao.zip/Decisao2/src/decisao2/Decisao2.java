/*
 * O programa deverá ler um número inteiro entre 1 e 12 e mostrar
 * o mês do ano referente. Por exemplo, o usuário digitou o número
 * 3, e o programa exibe Março.
 */
package decisao2;

import java.util.Scanner;

public class Decisao2 {
    public static void main(String[] args) {
        int mes;
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Entre com o mês: ");
        mes = entrada.nextInt();
        if (mes == 1) {
            System.out.println("Janeiro");
        } else if (mes == 2) {
            System.out.println("Fevereiro");
        } else if (mes == 3) {
            System.out.println("Março");
        } else if (mes == 4) {
            System.out.println("Abril");
        } else {
            System.out.println("Mês inválido");
        }
    }
}
