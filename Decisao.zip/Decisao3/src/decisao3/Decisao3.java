/*
 * O programa deverá ler um número inteiro entre 1 e 12 e mostrar
 * o mês do ano referente. Por exemplo, o usuário digitou o número
 * 3, e o programa exibe Março.
*/
package decisao3;

import java.util.Scanner;

public class Decisao3 {
    public static void main(String[] args) {
        int mes;
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Entre com o mês");
        mes = entrada.nextInt();
        switch (mes) {
            case 1: System.out.println("Janeiro");
                break;
            case 2: System.out.println("Fevereiro");
                break;   
            case 3: System.out.println("Março");
                break;
            case 4: System.out.println("Abril");
                break;
            case 12: System.out.println("Dezembro");
                break;
            default:  
                System.out.println("Mês inválido");
        }
    }
}
