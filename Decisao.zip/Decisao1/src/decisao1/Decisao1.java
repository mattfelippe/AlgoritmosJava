/*
 * O programa lê duas notas inteiras e calcula a média do aluno.
 * Depois o programa exibe se o aluno foi aprovado.
 * O aluno está aprovado se a média for maior ou igual a seis.
 * Se o aluno for reprovado, ler a nota da PF e recalcula a média.   
 * Se a média for maior ou igual a seis o aluno está aprovado.
 * Caso contrário o aluno estará reprovado.
 */
package decisao1;

import java.util.Scanner;

public class Decisao1 {
    public static void main(String[] args) {
        int nota1, nota2, nota3;
        double media;
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Entre com a nota 1: ");
        nota1 = teclado.nextInt();
        System.out.print("Entre com a nota 2: ");
        nota2 = teclado.nextInt();
        media = (double) (nota1 + nota2) / 2;
        if (media >= 6) {
            System.out.println("Aprovado com média = " + media);
        }
        else {
            System.out.println("Reprovado com média = " + media);
            System.out.print("Entre com a nota da PF: ");
            nota3 = teclado.nextInt();
            media = (media + nota3) / 2;
            if (media >= 6) {
                System.out.println("Aprovado com média = " + media);
            }
            else {
                System.out.println("Reprovado com média = " + media);    
            }
        }
    }
}