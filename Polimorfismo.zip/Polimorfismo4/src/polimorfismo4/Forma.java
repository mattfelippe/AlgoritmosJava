package polimorfismo4;

public abstract class Forma {
    
    abstract void exibe();
}

class Quadrado extends Forma {
    
    @Override
    public void exibe() {
    
        System.out.println("Eu sou um quadrado");
    }
}

class Triangulo extends Forma {
    
    @Override
    public void exibe() {
        
        System.out.println("Eu sou um triangulo");
    }
}

class Circulo extends Forma {
    
    @Override
    public void exibe() {
        
        System.out.println("Eu sou um círculo");
    }
}