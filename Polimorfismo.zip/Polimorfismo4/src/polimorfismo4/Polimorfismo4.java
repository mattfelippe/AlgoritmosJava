package polimorfismo4;

public class Polimorfismo4 {

    public static void main(String[] args) {
        Forma forma;
        
        forma = new Quadrado();
        forma.exibe();
        
        forma = new Triangulo();
        forma.exibe();
        
        forma = new Circulo();
        forma.exibe();
    }
}
