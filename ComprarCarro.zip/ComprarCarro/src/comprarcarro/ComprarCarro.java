package comprarcarro;

public class ComprarCarro {
    public static void main(String[] args) {
        final int NUMCARROS = 6;
        Carro[] carros = new Carro[NUMCARROS];
        double consumo, total, menor = Integer.MAX_VALUE;
        String modelo = "";
        
        criaCarros(carros);
        for (int i = 0; i < carros.length; i++) {
            consumo = calculaConsumo(carros[i]);
            total = calculaTotal(carros[i], consumo);
            mostraCarro(carros[i], consumo, total);
            if (total < menor) {
                menor = total;
                modelo = carros[i].getModelo();
            }
            System.out.println("");
        }
        System.out.println("Melhor modelo: " + modelo);
    }

    public static void mostraCarro(Carro carro, double consumo, double total) {
        
        System.out.printf("%s %.2f %.2f", carro, consumo, total);
    }
        
    public static double calculaTotal(Carro carro, double consumo) {
        double total;
        
        total = consumo + carro.getCustoCompra() + carro.getCustoImposto() +
                carro.getCustoSeguro();
        return total;
    }
    
    public static double calculaConsumo(Carro carro) {
        final int KM = 10000;
        final double GASOLINA = 3.98;
        double consumo;
        
        consumo = (KM / carro.getConsumoCombustivel()) * GASOLINA;
        return consumo;
    }
    
    public static void criaCarros(Carro[] carros) {
        
        carros[0] = new Carro("Onix", 36000, 1400, 11.8, 1600);
        carros[1] = new Carro("Fiesta", 32000, 1300, 13.5, 1800);
        carros[2] = new Carro("Fox", 31000, 1450, 12.3, 1300);
        carros[3] = new Carro("Polo", 41000, 1600, 13.5, 1500);
        carros[4] = new Carro("HB20", 40000, 1200, 11.6, 1200);
        carros[5] = new Carro("Sandero", 30000, 1300, 12.8, 1900);
    }    
}
