package lista5.ex3;

import java.util.Scanner;

public class Lista5Ex3 {
    public static void main(String[] args) {
        final int TAM = 5;
        final int FLAG = 0;
        int[] vet = new int[TAM];
        int num, pos = -1;
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Entre com um número: ");
        num = teclado.nextInt();
        while (num != FLAG) {
            pos++;
            vet[pos] = num;
            if (pos == vet.length-1) {
                System.out.println("Fim do vetor!");
                break;
            }
            System.out.print("Entre com um número: ");
            num = teclado.nextInt();
        }
        for (int i = pos; i >= 0; i--) {
            System.out.print(vet[i] + " ");
        }
    }
}
