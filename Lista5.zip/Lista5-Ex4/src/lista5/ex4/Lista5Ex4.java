package lista5.ex4;

import java.util.Scanner;

public class Lista5Ex4 {
    public static void main(String[] args) {
        final int TAM = 20;
        final int FLAG = 0;
        int[] vet = new int[TAM];
        int num, pos = -1, soma = 0;
        double media;
        
        num = leNumero();
        while (num != FLAG) {
            pos++;
            vet[pos] = num;
            soma += num;
            num = leNumero();
        }
        if (pos != -1) {
            media = calculaMedia(soma, pos+1);
            mostraNumeros(vet, pos, media);
        }
        else {
            System.out.println("Não há dados a serem processados!");
        }
    }
    
    public static void mostraNumeros(int[] vet, int tam, double media) {
        
        for (int i = 0; i <= tam; i++) {
            if (vet[i] >= media) {
                System.out.println(vet[i]);
            }
        }
    }
    
    public static double calculaMedia(int s, int quantidade) {
        double media;
        
        media = (double) s / quantidade;
        return media;
    }
    
    public static int leNumero() {
        int num;
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Entre com um número: ");
        num = entrada.nextInt();
        return num;
    }
}
