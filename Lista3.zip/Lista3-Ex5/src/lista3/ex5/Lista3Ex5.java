package lista3.ex5;

import java.util.Scanner;

public class Lista3Ex5 {
    public static void main(String[] args) {
        final int FIM = 0;
        Scanner entrada = new Scanner(System.in);
        int n, cont = 0,soma = 0;
        int maior = Integer.MIN_VALUE, menor = Integer.MAX_VALUE;
        double media;
        
        System.out.print("Entre com um número: ");
        n = entrada.nextInt();
        while (n != FIM) {
            soma = soma + n;
            if (n > maior) {
                maior = n;
            }
            if (n < menor) {
                menor = n;
            }
            cont++;
            System.out.print("Entre com um número: ");
            n = entrada.nextInt();
        }
        if (cont > 0) {
            media = (double) soma / cont;
            System.out.println("Soma = " + soma);
            System.out.println("Média = " + media);
            System.out.println("Maior = " + maior);
            System.out.println("Menor = " + menor);
        }
        else {
            System.out.println("Não há números a serem processados!");
        }
    }
}
