package lista3.ex10;

import java.util.Scanner;

public class Lista3Ex10 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int n;
        
        System.out.print("Entre com um número: ");
        n = entrada.nextInt();
        if (verificaPrimo3(n)) {
            System.out.println("É primo");
        }
        else {
            System.out.println("Não é primo");
        }
    }
    
    public static boolean verificaPrimo3(int n) {
        boolean eprimo = true;
        
        for (int i = 2; i <= (long) Math.sqrt(n); i++) {
            if ((n % i) == 0) {
                eprimo = false;
                break;
            }
        }
        return eprimo;
    }
        
    public static boolean verificaPrimo2(int n) {
        boolean eprimo = true;
        
        for (int i = 2; i <= n-1; i++) {
            if ((n % i) == 0) {
                eprimo = false;
                break;
            }
        }
        return eprimo;
    }
    
    public static boolean verificaPrimo1(int n) {
        boolean eprimo = true;
        
        for (int i = 2; i <= n-1; i++) {
            if ((n % i) == 0) {
                eprimo = false;
            }
        }
        return eprimo;
    }
}
