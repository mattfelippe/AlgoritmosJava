package lista3.ex8;

import java.util.Scanner;

public class Lista3Ex8 {
    public static void main(String[] args) {
        long t1 = 0, t2 = 1, t3;
        int numTermos;
        Scanner input = new Scanner(System.in);
        
        System.out.print("Entre o número de termos: ");
        numTermos = input.nextInt();
        System.out.print(t1 + " " + t2 + " ");
        for (int i = 3; i <= numTermos; i++) {
            t3 = t2 + t1;
            System.out.print(t3 + " ");
            t1 = t2;
            t2 = t3;
        }
    }
}
