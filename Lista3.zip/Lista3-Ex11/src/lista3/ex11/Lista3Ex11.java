package lista3.ex11;

import java.util.Scanner;

public class Lista3Ex11 {
    public static void main(String[] args) {
        final int FIM = 0;
        Scanner teclado = new Scanner(System.in);
        int n;
        
        System.out.print("Entre com um número: ");
        n = teclado.nextInt();
        while (n != FIM) {
            if (verificaPrimo3(n)) {
                System.out.println(n + " é primo");
            }
            else {
                System.out.println(n + " não é primo");
            }
            System.out.print("Entre com um número: ");
            n = teclado.nextInt();
        }
    }
    
    public static boolean verificaPrimo3(int n) {
        boolean eprimo = true;
        
        for (int i = 2; i <= (long) Math.sqrt(n); i++) {
            if ((n % i) == 0) {
                eprimo = false;
                break;
            }
        }
        return eprimo;
    }
}