package lista3.ex3;

import java.util.Scanner;

public class Lista3Ex3 {
    public static void main(String[] args) {
        final int LIM = 5;
        int num, soma = 0;
        int maior = Integer.MIN_VALUE, menor = Integer.MAX_VALUE;
        double media;
        Scanner entrada = new Scanner(System.in);

        for (int i = 1; i <= LIM; i++) {
            System.out.print("Entre com um número: ");
            num = entrada.nextInt();
            soma = soma + num;
            if (num > maior) {
                maior = num;
            }
            if (num < menor) {
                menor = num;
            }
        }
        media = soma / LIM;
        System.out.println("Soma = " + soma);
        System.out.println("Média = " + media);
        System.out.println("Maior = " + maior);
        System.out.println("Menor = " + menor);
    }
    
    /*
    public static void main(String[] args) {
        final int LIM = 5;
        double num, soma = 0;
        double maior = Math.pow(2, -31), menor = Math.pow(2, 31) - 1;
        double media;
        Scanner entrada = new Scanner(System.in);

        for (int i = 1; i <= LIM-1; i++) {
            System.out.print("Entre com um número: ");
            num = entrada.nextInt();
            soma = soma + num;
            if (num > maior) {
                maior = num;
            }
            if (num < menor) {
                menor = num;
            }
        }
        media = soma / LIM;
        System.out.println("Soma = " + soma);
        System.out.println("Média = " + media);
        System.out.println("Maior = " + maior);
        System.out.println("Menor = " + menor);
    }
    */    
    /*
    public static void main(String[] args) {
        final int LIM = 5;
        int num, soma = 0;
        int maior, menor;
        double media;
        Scanner entrada = new Scanner(System.in);

        System.out.print("Entre com um número: ");
        num = entrada.nextInt();
        maior = menor = num;
        for (int i = 1; i <= LIM-1; i++) {
            soma = soma + num;
            if (num > maior) {
                maior = num;
            }
            if (num < menor) {
                menor = num;
            }
            System.out.print("Entre com um número: ");
            num = entrada.nextInt();
        }
        media = (double) soma / LIM;
        System.out.println("Soma = " + soma);
        System.out.println("Média = " + media);
        System.out.println("Maior = " + maior);
        System.out.println("Menor = " + menor);
    }
    */
}