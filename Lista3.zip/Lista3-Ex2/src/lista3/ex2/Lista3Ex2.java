package lista3.ex2;

public class Lista3Ex2 {
    public static void main(String[] args) {
        int soma = 0;
        
        for (int i = 1; i <= 100; i++) {
            soma = soma + i;
        }
        System.out.println("Soma = " + soma);
    }
}
