package lista3.ex6;

import java.util.Scanner;

public class Lista3Ex6 {
    public static void main(String[] args) {
        int liminf, limsup;
        Scanner entrada = new Scanner(System.in);    
        
        System.out.print("Entre com o limite inferior: ");
        liminf = entrada.nextInt();
        System.out.print("Entre com o limite superior: ");
        limsup = entrada.nextInt();
        for (int i = liminf; i <= limsup; i++) {
            if (verificaPrimo3(i)) {
                System.out.println(i + " é primo");
            }
        }
    }
    
    public static boolean verificaPrimo3(int n) {
        boolean eprimo = true;
        
        for (int i = 2; i <= (long) Math.sqrt(n); i++) {
            if ((n % i) == 0) {
                eprimo = false;
                break;
            }
        }
        return eprimo;
    }
}
