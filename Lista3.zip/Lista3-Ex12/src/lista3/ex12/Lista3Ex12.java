package lista3.ex12;

import java.util.Scanner;

public class Lista3Ex12 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int mes;
        
        do {
            System.out.print("Entre com um mês: ");
            mes = input.nextInt();
            if ((mes < 1) || (mes > 12)) {
                System.out.println("Erro: mês inválido!");
            }    
        } while ((mes < 1) || (mes > 12));
    }
}
