package lista3.ex4;

import java.util.Scanner;

public class Lista3Ex4 {
    public static void main(String[] args) {
        int lim;
        int num, soma = 0;
        int maior = Integer.MIN_VALUE, menor = Integer.MAX_VALUE;
        double media;
        Scanner entrada = new Scanner(System.in);

        System.out.print("Entre com o número de repetições: ");
        lim = entrada.nextInt();
        for (int i = 1; i <= lim; i++) {
            System.out.print("Entre com um número: ");
            num = entrada.nextInt();
            soma = soma + num;
            if (num > maior) {
                maior = num;
            }
            if (num < menor) {
                menor = num;
            }
        }
        if (lim > 0) {
            media = (double) soma / lim;
            System.out.println("Soma = " + soma);
            System.out.println("Média = " + media);
            System.out.println("Maior = " + maior);
            System.out.println("Menor = " + menor);
        }    
        else {
            System.out.println("Não há números a serem processados!!!!");
        }
    }
}
