package lista3.ex9;

import java.util.Scanner;

public class Lista3Ex9 {
    public static void main(String[] args) {
        final int NUMTERMOS = 10;
        Scanner entrada = new Scanner(System.in);
        int t1, t2, t3, constante;
        
        System.out.print("Entre com o 1o termo: ");
        t1 = entrada.nextInt();
        System.out.print("Entre com o 2o termo: ");
        t2 = entrada.nextInt();        
        constante = t2 - t1;
        t3 = t2;
        for (int i = 1; i <= NUMTERMOS; i++) {
            t3 = t3 + constante;
            System.out.print(t3 + " ");
        }
    }
}
